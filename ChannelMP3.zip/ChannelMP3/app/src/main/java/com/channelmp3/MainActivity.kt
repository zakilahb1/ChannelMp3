package com.channelmp3

import android.app.Activity
import android.content.ContentValues
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.URI
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var link: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var start: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        layout.addView(TextView(this).apply { text = "Channel MP3"; textSize = 30f })
        layout.addView(TextView(this).apply {
            text = "Vidéos de la chaîne · de la plus récente à la plus ancienne"
        })
        link = EditText(this).apply {
            hint = "https://www.youtube.com/@chaine"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        layout.addView(link)
        start = Button(this).apply { text = "Télécharger en MP3" }
        layout.addView(start)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        layout.addView(progress)
        status = TextView(this).apply { textIsSelectable = true }
        layout.addView(status)
        setContentView(ScrollView(this).apply { addView(layout) })
        start.setOnClickListener {
            val url = channelVideosUrl(link.text.toString())
            if (url == null) {
                status.text = "Colle un lien de chaîne YouTube, par exemple youtube.com/@chaine."
                return@setOnClickListener
            }
            start.isEnabled = false
            progress.isIndeterminate = true
            status.text = "Chargement de la liste…"
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            Thread {
                try {
                    downloadChannel(url)
                } catch (error: Exception) {
                    report("Erreur : ${error.message.orEmpty().takeLast(900)}")
                } finally {
                    runOnUiThread {
                        start.isEnabled = true
                        progress.isIndeterminate = false
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }
            }.start()
        }
    }

    private fun downloadChannel(url: String) {
        val engine = YoutubeDL.getInstance()
        engine.init(applicationContext)
        FFmpeg.getInstance().init(applicationContext)
        val scan = YoutubeDLRequest(url).apply {
            addOption("--flat-playlist")
            addOption("--dump-single-json")
        }
        val channel = JSONObject(engine.execute(scan, null, null).out)
        val entries = channel.getJSONArray("entries")
        val videos = (0 until entries.length()).mapNotNull { entries.optJSONObject(it) }
        check(videos.isNotEmpty()) { "Aucune vidéo trouvée dans l’onglet Vidéos." }
        val name = listOf("channel", "uploader", "title")
            .map { channel.optString(it).removeSuffix(" - Videos").trim() }
            .firstOrNull { it.isNotBlank() && it != "null" } ?: "Chaîne YouTube"
        val folder = nextFolder(safeName(name, 90))
        val width = maxOf(3, videos.size.toString().length)
        val titles = mutableListOf<String>()
        val failures = mutableListOf<String>()
        val temp = java.nio.file.Files.createTempDirectory(cacheDir.toPath(), "mp3-").toFile()
        try {
            videos.forEachIndexed { index, video ->
                val number = String.format(Locale.ROOT, "%0${width}d", index + 1)
                val id = video.optString("id")
                val title = video.optString("title", id).replace(Regex("[\\r\\n]+"), " ")
                val line = "$number - $title"
                titles.add(line)
                report("Téléchargement ${index + 1}/${videos.size}\n$title", index, videos.size)
                val audio = File(temp, "$number.mp3")
                try {
                    require(id.matches(Regex("[A-Za-z0-9_-]{11}"))) { "Identifiant indisponible" }
                    val request = YoutubeDLRequest("https://www.youtube.com/watch?v=$id").apply {
                        addOption("--no-playlist")
                        addOption("--extract-audio")
                        addOption("--audio-format", "mp3")
                        addOption("--output", File(temp, "$number.%(ext)s").absolutePath)
                    }
                    engine.execute(request, null, null)
                    check(audio.isFile && audio.length() > 0) { "Fichier MP3 absent" }
                    audio.inputStream().use {
                        save(folder, "$number - ${safeName(title, 105)}.mp3", "audio/mpeg", it)
                    }
                } catch (error: Exception) {
                    failures.add("$line : ${error.message.orEmpty().lineSequence().lastOrNull { it.isNotBlank() }.orEmpty().take(220)}")
                } finally {
                    temp.listFiles()?.forEach { it.delete() }
                }
            }
            (titles.joinToString("\n", postfix = "\n")).byteInputStream(Charsets.UTF_8).use {
                save(folder, "titles.txt", "text/plain", it)
            }
            if (failures.isNotEmpty()) {
                failures.joinToString("\n", postfix = "\n").byteInputStream(Charsets.UTF_8).use {
                    save(folder, "erreurs.txt", "text/plain", it)
                }
            }
            report("Terminé : ${videos.size - failures.size}/${videos.size} MP3.\n$folder\ntitles.txt" +
                if (failures.isEmpty()) "" else "\n${failures.size} échec(s). Voir erreurs.txt.", videos.size, videos.size)
        } finally {
            temp.deleteRecursively()
        }
    }

    private fun nextFolder(name: String): String {
        val root = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "")
        var suffix = 1
        while (true) {
            val candidate = if (suffix == 1) name else "$name ($suffix)"
            val relative = "${Environment.DIRECTORY_DOWNLOADS}/$candidate/"
            val occupied = contentResolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Downloads._ID), "${MediaStore.Downloads.RELATIVE_PATH} = ?",
                arrayOf(relative), null)?.use { it.moveToFirst() } ?: false
            if (!occupied && !File(root, candidate).exists()) return relative
            suffix++
        }
    }

    private fun save(folder: String, name: String, mime: String, input: InputStream) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.RELATIVE_PATH, folder)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = checkNotNull(contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values))
        try {
            checkNotNull(contentResolver.openOutputStream(uri)).use { input.copyTo(it) }
            contentResolver.update(uri, ContentValues().apply {
                put(MediaStore.Downloads.IS_PENDING, 0)
            }, null, null)
        } catch (error: Exception) {
            contentResolver.delete(uri, null, null)
            throw error
        }
    }

    private fun report(message: String, done: Int? = null, total: Int = 1) = runOnUiThread {
        status.text = message
        if (done != null) {
            progress.isIndeterminate = false
            progress.max = total
            progress.progress = done
        }
    }
}

internal fun channelVideosUrl(input: String): String? {
    val trimmed = input.trim()
    val uri = runCatching { URI(if (trimmed.contains("://")) trimmed else "https://$trimmed") }
        .getOrNull() ?: return null
    if (uri.scheme !in setOf("https", "http") ||
        uri.host?.lowercase() !in setOf("youtube.com", "www.youtube.com", "m.youtube.com") ||
        uri.userInfo != null || uri.port != -1) return null
    val path = uri.rawPath.trimEnd('/')
    val match = Regex("^(/@[^/]+|/(?:channel|c|user)/[^/]+)(?:/videos)?$").matchEntire(path) ?: return null
    return "https://www.youtube.com${match.groupValues[1]}/videos"
}

internal fun safeName(value: String, limit: Int): String =
    value.map { if (it.isISOControl() || it in "<>:\"/\\|?*") '_' else it }
        .joinToString("").take(limit).trim(' ', '.').ifBlank { "Sans titre" }
