# Channel MP3

Application Android pour ARM64, Android 10 ou supérieur.

1. Collez le lien d'une chaîne YouTube, par exemple `https://www.youtube.com/@nom`.
2. Appuyez sur **Télécharger en MP3** et laissez l'application ouverte.
3. Dans **Mes fichiers → Téléchargements**, ouvrez le dossier au nom de la chaîne.

L'application conserve l'ordre retourné par l'onglet **Vidéos**, normalement de la publication la plus récente à la plus ancienne. Elle ne parcourt pas les onglets distincts Shorts ou En direct. Les préfixes 001, 002, etc. conservent cet ordre quand on trie les fichiers par nom. Le fichier UTF-8 `titles.txt` reprend la liste entière dans le même ordre. Si un téléchargement échoue, son numéro reste réservé et `erreurs.txt` indique le titre concerné. Une nouvelle exécution utilise un nouveau dossier si le nom existe déjà.

## Générer l'APK sur PC

Ouvrez le dossier ChannelMP3 dans Android Studio, utilisez le JDK 17 pour Gradle et installez Android SDK Platform 35 si Android Studio le demande. Après la synchronisation, exécutez `gradlew.bat :app:assembleDebug` dans l'invite de commandes Windows à la racine du projet. Le fichier sera dans `app/build/outputs/apk/debug/app-debug.apk`. Transférez-le sur le téléphone et ouvrez-le.

## Générer l'APK sur GitHub

Déposez le contenu de ChannelMP3 à la racine d'un dépôt GitHub, y compris le dossier caché `.github`. Ouvrez **Actions → Build Android APK → Run workflow**. Après réussite, téléchargez l'artefact **ChannelMP3-APK** et décompressez-le pour récupérer l'APK.

La compilation n'a pas abouti dans l'environnement de création, qui n'a pas pu télécharger Gradle. Le téléchargement et l'installation sur appareil restent à vérifier.

Le projet utilise [youtubedl-android et FFmpeg](https://github.com/JunkFood02/youtubedl-android). Les [conditions de YouTube](https://www.youtube.com/t/terms) précisent les téléchargements autorisés.
